﻿namespace Aduanas.Aci.Seguridad.Api.DTOs.Rol
{
    public class RolDTO
    {
        public int IdRol { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public string Descripcion { get; set; } = string.Empty;
    }
}
